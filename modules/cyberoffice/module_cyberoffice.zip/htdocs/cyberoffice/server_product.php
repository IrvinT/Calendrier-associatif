<?php
/**
 *	CyberOffice
 *
 *  @author    LVSinformatique <contact@lvsinformatique.com>
 *  @copyright 2014 LVSInformatique
 *	@license   NoLicence
 *  @version   1.2.31
 */		

// This is to make Dolibarr working with Plesk
set_include_path($_SERVER['DOCUMENT_ROOT'].'/htdocs');
require_once '../master.inc.php';
require_once DOL_DOCUMENT_ROOT.'/cyberoffice/class/nusoap/lib/nusoap.php'; 
require_once DOL_DOCUMENT_ROOT.'/core/lib/ws.lib.php';
require_once DOL_DOCUMENT_ROOT.'/user/class/user.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/files.lib.php';
require_once DOL_DOCUMENT_ROOT.'/societe/class/societe.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/extrafields.class.php';
require_once DOL_DOCUMENT_ROOT.'/product/class/product.class.php';
require_once DOL_DOCUMENT_ROOT.'/categories/class/categorie.class.php';
require_once DOL_DOCUMENT_ROOT.'/cyberoffice/class/cyberoffice.class.php';
dol_syslog("cyberoffice::Call Dolibarr webservices interfaces::ServerProduct_0");
//set_time_limit(3600);
@ini_set('default_socket_timeout', 160);
$langs->load("main");

// Enable and test if module web services is enabled
if (empty($conf->global->MAIN_MODULE_WEBSERVICES))
{
	$langs->load("admin");
	dol_syslog("Call Dolibarr webservices interfaces with module webservices disabled");
	print $langs->trans("WarningModuleNotActive",'WebServices').'.<br><br>';
	print $langs->trans("ToActivateModule");
	exit;
}

// Create the soap Object
$server = new nusoap_server();
$server->soap_defencoding='UTF-8';
$server->decode_utf8=false;
$ns='http://www.lvsinformatique.com/ns/';
$server->configureWSDL('WebServicesDolibarrProduct',$ns);
$server->wsdl->schemaTargetNamespace=$ns;


// Define WSDL Authentication object
$server->wsdl->addComplexType(
    'authentication',
    'complexType',
    'struct',
    'all',
    '',
    array(
        'dolibarrkey' => array('name'=>'dolibarrkey','type'=>'xsd:string'),
    	'sourceapplication' => array('name'=>'sourceapplication','type'=>'xsd:string'),
    	'login' => array('name'=>'login','type'=>'xsd:string'),
        'password' => array('name'=>'password','type'=>'xsd:string'),
        'entity' => array('name'=>'entity','type'=>'xsd:string'),
        'myurl' => array('name'=>'myurl','type'=>'xsd:string')
    )
);
// Define WSDL Return object
$server->wsdl->addComplexType(
    'result',
    'complexType',
    'struct',
    'all',
    '',
    array(
        'result_code' => array('name'=>'result_code','type'=>'xsd:string'),
        'result_label' => array('name'=>'result_label','type'=>'xsd:string')
    )
);

// Define specific object
$server->wsdl->addComplexType(
    'params',
    'complexType',
    'struct',
    'all',
    '',
	array(
		'id_product' 			=> array('name'=>'id_product','type'=>'xsd:string'),
		'ean13' 				=> array('name'=>'ean13','type'=>'xsd:string'),
		'upc' 					=> array('name'=>'upc','type'=>'xsd:string'),
		'price' 				=> array('name'=>'price','type'=>'xsd:string'),
		'width' 				=> array('name'=>'width','type'=>'xsd:string'),
		'weight' 				=> array('name'=>'weight','type'=>'xsd:string'),
		'description' 			=> array('name'=>'description','type'=>'xsd:string'),
		'description_short' 	=> array('name'=>'description_short','type'=>'xsd:string'),
		'name' 					=> array('name'=>'name','type'=>'xsd:string'),
		'tax_rate' 				=> array('name'=>'tax_rate','type'=>'xsd:string'),
		'reference'				=> array('name'=>'reference','type'=>'xsd:string'),
		'active'				=> array('name'=>'active','type'=>'xsd:string'),
		'quantity'				=> array('name'=>'quantity','type'=>'xsd:string'),
		'warehouse'				=> array('name'=>'warehouse','type'=>'xsd:string'),
		'image'					=> array('name'=>'image','type'=>'xsd:string'),
		'category'				=> array('name'=>'category','type'=>'xsd:string'),
		'product_url'			=> array('name'=>'product_url','type'=>'xsd:string'),
		'manufacturer'			=> array('name'=>'manufacturer','type'=>'xsd:string'),
		'id_manufacturer'		=> array('name'=>'id_manufacturer','type'=>'xsd:string'),
		'eco_tax'				=> array('name'=>'eco_tax','type'=>'xsd:string'),
		'match'					=> array('name'=>'match','type'=>'xsd:string'),
		'wholesale_price'		=> array('name'=>'wholesale_price','type'=>'xsd:string')
		)
);

// 5 styles: RPC/encoded, RPC/literal, Document/encoded (not WS-I compliant), Document/literal, Document/literal wrapped
$styledoc='rpc';       // rpc/document (document is an extend into SOAP 1.0 to support unstructured messages)
$styleuse='encoded';   // encoded/literal/literal wrapped

// Register WSDL
$server->register(
    'Create',
    // Entry values
    array('authentication'=>'tns:authentication','params'=>'tns:params'),
    // Exit values
    array('result'=>'tns:result','description'=>'xsd:string'),
    $ns,
    $ns.'#Create',
    $styledoc,
    $styleuse,
    'WS to Create Product'
);
function Create($authentication,$params)
{
	global $db,$conf,$langs;
		if ($conf->global->CYBEROFFICE_chanel==0) CreateWoCurl($authentication,$params);
			else CreateWCurl($authentication,$params);
}
function CreateWoCurl($authentication,$params)
{
    global $db,$conf,$langs;
    
    $now=dol_now();

    dol_syslog("cyberoffice::Function: CreateWoCurl login=".$authentication['login']);
    $_POST["authentication"] = $authentication;
    $_POST["params"] = $params;
    include ('server_product.inc.php');
}
function CreateWCurl($authentication,$params)
{
	global $db,$conf,$langs;
		$pageURL = 'http';
 		if ($_SERVER["HTTPS"] == "on") $pageURL .= "s";
 			$pageURL .= "://";
 		$pageURL0 = $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 		if ($_SERVER["SERVER_PORT"] == "80" || $_SERVER["SERVER_PORT"] == "443") 
  			$pageURL0 = $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 		$pageURL .= $pageURL0;
 		$pageURL1 = str_replace('server_product.php', 'server_product_ws3.php',$pageURL);
		dol_syslog("cyberoffice::envoi curl sur ".$pageURL1);
		$nbcanal = (($conf->global->CYBEROFFICE_chanel && (int)$conf->global->CYBEROFFICE_chanel>0)?(int)$conf->global->CYBEROFFICE_chanel:5);
		$number=sizeof($params,0);
		$partlen = floor( $number / $nbcanal );
		$partrem = $number % $nbcanal;
		$partition = array();
    	$mark = 0;
    	for ($px = 0; $px < $nbcanal; $px++) {
	        $incr = ($px < $partrem) ? $partlen + 1 : $partlen;
	        $partition[$px] = array_slice( $params, $mark, $incr );
	        $mark += $incr;
	    }
	    $cmi = curl_multi_init();
    	for ($px = 0; $px < $nbcanal; $px++) {
			$fields = array('authentication' => $authentication,'params' => $partition[$px]);
			$field_string = http_build_query($fields);
			${'ch'.$px}= curl_init();
			curl_setopt(${'ch'.$px}, CURLOPT_URL, $pageURL1);
			curl_setopt(${'ch'.$px},CURLOPT_RETURNTRANSFER,false);
			//curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
			//curl_setopt($ch, CURLOPT_TIMEOUT, 1);
			//curl_setopt($ch, CURLOPT_TIMEOUT_MS, 1);
			curl_setopt(${'ch'.$px}, CURLOPT_USERAGENT, 'CURL');
			curl_setopt(${'ch'.$px}, CURLOPT_POST, 1);//sizeof($fields)
	    	curl_setopt(${'ch'.$px}, CURLOPT_POSTFIELDS, $field_string);
	    	curl_multi_add_handle($cmi, ${'ch'.$px});
    	}
    	
    	$running = null;
    	$active = null;
    	
    	do {
			$mrc = curl_multi_exec($cmi, $active);
		} while ($mrc == CURLM_CALL_MULTI_PERFORM);
		/*
		while ($active && $mrc == CURLM_OK) {
			if (curl_multi_select($cmi) != -1) {
				do {
					$mrc = curl_multi_exec($cmi, $active);
				} while ($mrc == CURLM_CALL_MULTI_PERFORM);
			}
		}
		*/
		while ($active && $mrc == CURLM_OK) {
			// Wait for activity on any curl-connection
			if (curl_multi_select($cmi) == -1) {
				usleep(1);
			}
			// Continue to exec until curl is ready to
			// give us more data
			do {
				$mrc = curl_multi_exec($cmi, $active);
			} while ($mrc == CURLM_CALL_MULTI_PERFORM);
		}
		
    	/*
    	do {
			$mrc = curl_multi_exec($cmi, $running);
			sleep(1);
			break;
		} while ($running > 0);
		*/
		for ($px = 0; $px < $nbcanal; $px++) {
			curl_multi_remove_handle($cmi, ${'ch'.$px});
		}
		curl_multi_close($cmi);
		$objectresp=array('result::e'=>array('result_code'=>'result_code', 'result_label'=>'result_label'),'description'=>'description');
		return $objectresp;
}
function Creates($authentication,$params)
{
		$pageURL = 'http';
 		if ($_SERVER["HTTPS"] == "on") $pageURL .= "s";
 			$pageURL .= "://";
 		if ($_SERVER["SERVER_PORT"] != "80") 
  			$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 		else 
  			$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 
 		$pageURL1 = str_replace('server_product.php', 'server_product_ws3.php',$pageURL);

		$fields = array('authentication' => $authentication,'params' => $params);
		$field_string = http_build_query($fields);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $pageURL1);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,false);
		//curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
		//curl_setopt($ch, CURLOPT_TIMEOUT, 1);
		//curl_setopt($ch, CURLOPT_TIMEOUT_MS, 1);
		curl_setopt($ch, CURLOPT_USERAGENT, 'CURL');
		curl_setopt($ch, CURLOPT_POST, 1);//sizeof($fields)
    	curl_setopt($ch, CURLOPT_POSTFIELDS, $field_string);
		curl_exec($ch);
		curl_close($ch);
		$objectresp=array('resulte'=>array('result_code'=>'result_code', 'result_label'=>'result_label'),'description'=>'description');
		return $objectresp;
}
function Create2($authentication,$params)
{
    global $db,$conf,$langs;
    
    $now=dol_now();

    dol_syslog("cyberoffice::Function: create login=".$authentication['login']);

    if ($authentication['entity']) $conf->entity=$authentication['entity'];

    // Init and check authentication
    $objectresp=array();
    $errorcode='';$errorlabel='';
    $error=0;
    $fuser=check_authentication($authentication,$error,$errorcode,$errorlabel);
    $error=0;
dol_syslog("CyberOffice_server_product::line=".__LINE__);
        include_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';

        $newobject=new Product($db);
        $db->begin();
//dol_syslog("CyberOffice_server_product::params=".print_r($params));
        //echo "<pre>".print_r($params)."</pre>";die();
        dol_syslog("CyberOffice_server_product::nb produits=".count($params));
        $socid_old=0;
        
        $user = new User($db);
        $user->fetch('', $authentication['login'],'',0);
		$user->getrights();

        $cyber = new Cyberoffice;
		$cyber->entity = 0;
		$cyber->myurl = $authentication['myurl'];
		$indice = $cyber->numShop();

        $objectcat=new Categorie($db);
        $catparent0 = array();
		if (DOL_VERSION < '3.8.0')
			$catparent0 = $objectcat->rechercher(null,$cyber->myurl,0);
		else
			$catparent0 = $objectcat->rechercher(null,$cyber->myurl,'product');

        foreach ($catparent0 as $cat_parent0)
		{
			$idparent0 = $cat_parent0->id;
		}


        foreach ($params as $product)
		{
			//echo "<pre>".print_r($product)."</pre>";die();
			dol_syslog("CyberOffice_server_product::traitement produit=".$product['id_product']);
			//if (count($product['declinaison']) > 0) 
			//{
				//foreach ($product['declinaison']as $declinaison)
				//{
					/*****recherche de la correspondance
					************************************/
					if ($product['match'] == '{ref}' && !$product['reference']) {
						$list_ok.= "<br/>ERROR ref ".$product['id_product'];
						dol_syslog("CyberOffice_server_product::ERROR ref ".$product['id_product']);
						continue;
					}

					/***** test produit parent
					**************************/
					$nbr = strpos($product['id_product'], '-');
					if ($nbr === false) $nbr=0;
					$product_id_product = "P".$indice."-".substr($product['id_product'],0,$nbr);
					$sql = 'SELECT rowid FROM '.MAIN_DB_PREFIX.'product WHERE import_key="'.$product_id_product.'"';
					dol_syslog("CyberOffice_server_product::fetch combination sql=".$sql);
					if ($nbr>0) {
						$resql = $db->query($sql);
						if ($resql) {
							if ($db->num_rows($resql) > 0) {
								$res = $db->fetch_array($resql);
								$produit_id=$res['rowid'];
							} else $produit_id=0;
						} else $produit_id=0;
						if ($produit_id > 0) {
								$sql = "UPDATE ".MAIN_DB_PREFIX."product SET";
								$sql .= " import_key='P".$indice."-".$product['id_product']."'";
								$sql.= " WHERE rowid=".$produit_id;
								dol_syslog("server_product::update combination - sql=".$sql);
								$resql = $db->query($sql);
							}
					}

					$sql = "SELECT rowid";
						$sql.= " FROM ".MAIN_DB_PREFIX."product";
						if ($product['match'] == '{ref}')
							$sql.= " WHERE ref = '".$product['reference']."'";
						else
							$sql.= " WHERE import_key = 'P".$indice."-".$product['id_product']."'";
						dol_syslog("CyberOffice_server_product::fetch sql=".$sql);
						$resql = $db->query($sql);
						if ($resql) {
							if ($db->num_rows($resql) > 0) {
								$res = $db->fetch_array($resql);
								$produit_id=$res['rowid'];
							} else $produit_id=0;
						} else $produit_id=0;
					if ($db->num_rows($resql) > 1 && $product['match'] == '{ref}') {
						//$error++;
						$list_ok.= "<br/>ERROR ref ".$product['reference']." x ".$db->num_rows($resql);
						dol_syslog("CyberOffice_server_product::ERROR ref ".$product['reference']." x ".$db->num_rows($resql));
						continue;
					}
					/*****creation
					**************/
					$newobject->price_base_type 	= 'HT';
					$newobject->price				= $product['price'];
					$newobject->price_ttc 			= price2num($product['price'] * (1 + ($product['tax_rate'] / 100)),'MU');
					$newobject->tva_tx				= $product['tax_rate'];
					if (DOL_VERSION < '3.8.0')
						$newobject->libelle				= $product['name'];
					else
						$newobject->label				= $product['name'];
					$newobject->description			= $product['description_short'];
					$newobject->array_options		= array("options_longdescript"=>trim($product['description']));
					$newobject->type				= 0;
					$newobject->status				= $product['active'];
					$newobject->status_buy			= 1;
					if ($conf->global->MAIN_MODULE_BARCODE) {
						$newobject->barcode				= ($product['ean13']?$product['ean13']:$product['upc']);
						$newobject->barcode_type		= ($product['ean13']?2:3);
					}
					$newobject->ref					= '';
					if (!empty($product['reference'])) {
						$newobject->ref = $product['reference'];
						dol_syslog("CyberOffice_server_product::ref1 =".$newobject->ref);
					} else {
						// Load object modCodeProduct
						$module=(! empty($conf->global->PRODUCT_CODEPRODUCT_ADDON)?$conf->global->PRODUCT_CODEPRODUCT_ADDON:'mod_codeproduct_leopard');
						if ($module != 'mod_codeproduct_leopard')	// Do not load module file for leopard
						{
							if (substr($module, 0, 16) == 'mod_codeproduct_' && substr($module, -3) == 'php')
							{
								$module = substr($module, 0, dol_strlen($module)-4);
							}
							dol_include_once('/core/modules/product/'.$module.'.php');
							$modCodeProduct = new $module;
							if (! empty($modCodeProduct->code_auto))
							{
								$newobject->ref = $modCodeProduct->getNextValue($newobject,$newobject->type);
							}
							unset($modCodeProduct);
						}
						if (empty($newobject->ref) || !$newobject->ref) $newobject->ref = 'Presta'.$product['id_product'];
					}
					dol_syslog("CyberOffice_server_product::ref2 =".$newobject->ref);
					$user = new User($db);
					$Ruser=$user->fetch('', $authentication['login'],'',0);
					//echo "<pre>".print_r($user)."</pre>";die();
					
					/* vérification ref existant
					****************************/
					$sql = "SELECT count(*) as nb";
					$sql.= " FROM ".MAIN_DB_PREFIX."product";
					$sql.= " WHERE (ref = '" .$newobject->ref."' OR ref LIKE '".$newobject->ref."(%')";
					$sql.= " AND import_key != 'P".$indice."-".$product['id_product']."'";
					if ($product['match'] == '{ref}') $resultCheck = '';
						else $resultCheck = $db->query($sql);
					if ($resultCheck )
					{
						$obj = $db->fetch_object($resultCheck );
						if ($obj->nb > 0) $newobject->ref = $newobject->ref.'('.($obj->nb + 1).')';
					}

					$result=$produit_id;
					if ($produit_id == 0) {
						$newobject->oldcopy='';
						$result = $newobject->create($user);
						if ($result > 0) {
							$produit_id=$result;
							$list_ok.="<br/>Create Product : ".$result. ' : ' .$product['name'];
							$sql = "UPDATE ".MAIN_DB_PREFIX."product SET";
							$sql .= " import_key='P".$indice."-".$product['id_product']."'";
							$sql.= " WHERE rowid=".$result;
							dol_syslog("server_product::update - sql=".$sql);
							$resql = $db->query($sql);
						}
					} //else {
						/*****modification
						******************/
						$sql = "SELECT rowid";
						$sql.= " FROM ".MAIN_DB_PREFIX."product";
						if ($product['match'] == '{ref}')
							$sql.= " WHERE ref = '".$product['reference']."'";
						else
							$sql.= " WHERE import_key = 'P".$indice."-".$product['id_product']."'";
						dol_syslog("CyberOffice_server_product::fetch2 sql=".$sql);
						$resql = $db->query($sql);
						if ($resql) {
							if ($db->num_rows($resql) > 0) {
								$res = $db->fetch_array($resql);
								$produit_id=$res['rowid'];
								$newobject->fetch($produit_id);
							} else $produit_id=0;
						} else $produit_id=0;
						if ($db->num_rows($resql) > 1 && $product['match'] == '{ref}') {
							//$error++;
							$list_ok.= "<br/>ERROR ref ".$product['reference']." x ".$db->num_rows($resql);
							dol_syslog("CyberOffice_server_product::ERROR ref ".$product['reference']." x ".$db->num_rows($resql));
							continue;
						}
						//(dol_textishtml($object->description)?$object->description:dol_nl2br($object->description,1,true))
						$newobject->url					= $product['product_url'];
						if (DOL_VERSION < '3.8.0')
							$newobject->libelle				= $product['name'];
						else
							$newobject->label				= $product['name'];

						$newobject->description			= $product['description_short'];
						$newobject->array_options		= array("options_longdescript"=>trim($product['description']));
						$newobject->weight			 	= $product['weight'];
						$newobject->length 				= $product['width'];
						$newobject->ref 				= $product['reference'];
						$newobject->weight_units 		= 0;
						$newobject->length_units 		= -2;
						$newobject->price_base_type 	= 'HT';
						$newobject->price				= $product['price'];
						$newobject->tva_tx				= $product['tax_rate'];
						$newobject->price_ttc 			= price2num($product['price'] * (1 + ($product['tax_rate'] / 100)),'MU');
						$newobject->id					= $produit_id;
						if ($conf->global->MAIN_MODULE_BARCODE) {
							$newobject->barcode				= ($product['ean13']?$product['ean13']:$product['upc']);
							$newobject->barcode_type		= ($product['ean13']?2:3);
						}
						if ($produit_id>0) {
							/* vérification ref existant
							****************************/
							$sql = "SELECT count(*) as nb";
							$sql.= " FROM ".MAIN_DB_PREFIX."product";
							$sql.= " WHERE (ref = '" .$newobject->ref."' OR ref LIKE '".$newobject->ref."(%')";
							$sql.= " AND import_key != 'P".$indice."-".$product['id_product']."'";
							if ($product['match'] == '{ref}') $resultCheck = '';
								else $resultCheck = $db->query($sql);
							if ($resultCheck )
							{
								$obj = $db->fetch_object($resultCheck );
								if ($obj->nb > 0) $newobject->ref = $newobject->ref.'('.($obj->nb + 1).')';
							}

							$product_price = new Product($db);
							$product_price->fetch($produit_id);
							if (round($product_price->price,3) != round($product['price'],3) || round($product_price->tva_tx,3) != round($product['tax_rate'],3))
								$newobject->updatePrice($product['price'], 'HT', $user, $product['tax_rate']);
							$newobject->oldcopy='';
							$resultS_U=$newobject->update($produit_id,$user);
						}
						if ($resultS_U> 0) $list_ok.="<br/>Update Product : ".$product['id_product'].'->'.$produit_id . ' : ' .$product['name'];
					//}
					/*****mise à jour du stock
					**************************/
					$newobject->id=$produit_id;
					//$stock=$newobject->load_stock();
					$sql = "SELECT ps.reel, ps.pmp, ps.rowid as product_stock_id";
					$sql.= " FROM ".MAIN_DB_PREFIX."product_stock as ps";
					$sql.= " WHERE ps.fk_entrepot = ".$product['warehouse'];
					$sql.= " AND ps.fk_product = ".$newobject->id;
					$resql = $db->query($sql);
					if ($resql) {
						if ($db->num_rows($resql) > 0) {
							$res = $db->fetch_array($resql);
							$stockW=$res['reel'];
						} else $stockW=0;
					} else $stockW=0;
					$quantity=$product['quantity'] - $stockW;//$newobject->stock_reel;
					if ($quantity != 0) $newobject->correct_stock($user, $product['warehouse'], $quantity, 0, 'PrestaShop');

					/*****photo
					***********/
					dol_syslog("CyberOffice_server_product::IMAGE -> ".$product['image']);
					if( $product['image'] ) {
							$picture = $product['image'];
							$name = explode("/",$picture);
							$name = $name[sizeof($name)-1];
							$ext=preg_match('/(\.gif|\.jpg|\.jpeg|\.png|\.bmp)$/i',$picture,$reg);
							$imgfonction='';
							if (strtolower($reg[1]) == '.gif')  $ext= 'gif';
							if (strtolower($reg[1]) == '.png')  $ext= 'png';
							if (strtolower($reg[1]) == '.jpg')  $ext= 'jpeg';
							if (strtolower($reg[1]) == '.jpeg') $ext= 'jpeg';
							if (strtolower($reg[1]) == '.bmp')  $ext= 'wbmp';
			
							$file = array("tmp_name"=>"images_temp/temp.$ext","name"=>$name);
									
							$img = @call_user_func_array("imagecreatefrom".$ext,array($picture));
							
							$upload_dir = $conf->product->multidir_output[$conf->entity];
									
							$sdir = $conf->product->multidir_output[$conf->entity];
							//$dir = $sdir .'/'. get_exdir($produit_id,2) . $produit_id ."/";
							//$dir .= "photos/";
							
							if (! empty($conf->global->PRODUCT_USE_OLD_PATH_FOR_PHOTO)) {
								if (DOL_VERSION < '3.8.0')
									$dir = $sdir .'/'. get_exdir($produit_id,2) . $produit_id ."/photos";
								else $dir = $sdir .'/'. get_exdir($produit_id,2,0,0,$newobject,'product') . $produit_id ."/photos";
							} else 
								$dir = $sdir .'/'.dol_sanitizeFileName($product['reference']);
							dol_syslog("CyberOffice_server_product::IMAGE dir ".$dir);
							if (! file_exists($dir)) dol_mkdir($dir);//,'','0705');
							
							@call_user_func_array("image$ext",array($img,$dir.'/'.$file['name']));
							@imagedestroy($img);
							include_once DOL_DOCUMENT_ROOT.'/core/lib/images.lib.php';
									if (image_format_supported($dir.'/'.$file['name']) == 1)
									{
										// Create small thumbs for image (Ratio is near 16/9)
										// Used on logon for example
										$imgThumbSmall = vignette($dir.'/'.$file['name'], 160, 120, '_small', 50, "thumbs");
										// Create mini thumbs for image (Ratio is near 16/9)
										// Used on menu or for setup page for example
										$imgThumbMini = vignette($dir.'/'.$file['name'], 160, 120, '_mini', 50, "thumbs");
									}

							$list_ok.="<br/>Image Product : ".$dir.'/'.$file['name']. ' : ' .$product['name'];
							dol_syslog("CyberOffice_server_product::IMAGE Product : ".$dir.'/'.$file['name']. ' : ' .$product['name']);
					}
					/***** category 
					***************/
					if($newobject->id==0) $newobject->fetch($produit_id);
					$sql  = "DELETE FROM ".MAIN_DB_PREFIX."categorie_product";
					$sql .= " WHERE fk_product=".$newobject->id;
					$resql = $db->query($sql);
					$categs = explode('-',$product['category']);
					foreach ($categs  as $categ)
					{
						$sql = "SELECT rowid";
						$sql.= " FROM ".MAIN_DB_PREFIX."categorie";
						$sql.= " WHERE import_key = 'P".$indice."-".$categ."'";
						dol_syslog("CyberOffice_server_product::fetch sql=".$sql);
						$resql = $db->query($sql);
						if ($resql) {
							if ($db->num_rows($resql) > 0) {
								$res = $db->fetch_array($resql);
								$res_rowid=$res['rowid'];
							} else $res_rowid=0;
						} else $res_rowid=0;
						if ($res_rowid==0) $res_rowid=$idparent0;
						if ($res_rowid != 0) {
							$cat = new Categorie($db);
							$result_Cat=$cat->fetch($res_rowid);
							$result_Cat=$cat->add_type($newobject,'product');
						}
					}
					/****** manufacurer
					*******************/
					/*
					$newobject_m=new Societe($db);
					$sql = "SELECT rowid";
					$sql.= " FROM ".MAIN_DB_PREFIX."societe";
					$sql.= " WHERE import_key = 'P".$indice."m-".$product['id_manufacturer']."'";
					dol_syslog("CyberOffice_server_product::fetch sql=".$sql);
					$resql = $db->query($sql);
					if ($resql) {
						if ($db->num_rows($resql) > 0) {
							$res = $db->fetch_array($resql);
							$res_manufacturer=$res['rowid'];
						} else $res_manufacturer = 0;
					} else $res_manufacturer = 0;
					$newobject_m->status				= 1;
					$newobject_m->name 				= $product['manufacturer'];
					$newobject_m->client				= 0;
					$newobject_m->fournisseur			= 1;
					$newobject_m->import_key			= "P".$indice."m-".$product['id_manufacturer'];
					$newobject_m->code_fournisseur	= -1;
					if ($res_manufacturer == 0) $resultM = $newobject_m->create($user);
					*/
					if ($result <= 0) {
					
						$error++;
						$list_id.= ' '.$product['id_product'];
						if (DOL_VERSION < '3.8.0')
							$list_ref.= ' '.$newobject->libelle;
						else
							$list_ref.= ' '.$newobject->label;
						dol_syslog("CyberOffice_server_productERROR::product=".$product['id_product'].'::'.$result,LOG_ERR);
					} 
				//}//fin foreach declinaison
			//}//fin if count
		}  //fin foreach
		
  

        if (! $error || $error==0)
        {
            $db->commit();
            $objectresp=array('result'=>array('result_code'=>'OK', 'result_label'=>''),'description'=>$list_ok);
        }
        else
        {
            $db->rollback();
            $error++;
            $errorcode='KO';
            $errorlabel=$list_ok.'<br/>'.$newobject->error;
        }
	
    if ($error && $error > 0)
    {
        $objectresp = array('result'=>array('result_code' => $errorcode, 'result_label' => $errorlabel),'description'=>$list_id);
    }

    return $objectresp;
}

// Return the results.
$server->service(file_get_contents("php://input"));