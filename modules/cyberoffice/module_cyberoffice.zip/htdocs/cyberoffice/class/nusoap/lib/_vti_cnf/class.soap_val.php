vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Feb 2015 08:23:34 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|LVSi\\LVSInformatique
vti_modifiedby:SR|LVSi\\LVSInformatique
vti_timecreated:TR|27 Feb 2015 08:23:34 -0000
vti_cacheddtm:TX|27 Feb 2015 08:23:34 -0000
vti_filesize:IR|2616
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
vti_backlinkinfo:VX|
vti_syncwith_ftp.cluster006.ovh.net\:21:TX|27 Feb 2015 08:23:34 -0000
vti_syncofs_ftp.cluster006.ovh.net\:21:TW|21 Apr 2016 09:16:53 -0000
